#pragma once
#include "spaceObject.h"

class bonus : public  spaceObject
{
	int cntAmmunition;
	int existingTime;
public:

	bonus();

	void setCntAmmunition();
	void outputCntAmmunition();
	void setExistingTime();
	void outputExistingTime();
	void outData() override;

};
