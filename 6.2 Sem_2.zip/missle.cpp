#include "spaceObject.h"
#include "missle.h"
#include <iostream>
using namespace std;

missle :: missle()
{
	explosivePower = 0;
	fuel_time = 0;
}

void missle::setExplosivePower()
{
	cout << "Enter explosivePower" << endl;
	cin >> explosivePower;
	if (explosivePower < 0)
	{
		cout << "Incorrect value" << endl;
		exit(1);
	}
}
void missle::outputExplosivePower()
{
	cout << "explosivePower: " << explosivePower << endl;
}
void missle::setFuel_time()
{
	cout << "Enter fuel_time" << endl;
	cin >> fuel_time;
	if (fuel_time < 0)
	{
		cout << "Incorrect value" << endl;
		exit(1);
	}
}
void missle::outputFuel_time()
{
	cout << "fuel_time: " << fuel_time << endl;
}
void missle::outData()
{
	cout << endl;
	cout << "Missle: " << endl;
	outputCoordinates();
	outputSpeed();
	outputExplosivePower();
	outputFuel_time();
	cout << endl;
}