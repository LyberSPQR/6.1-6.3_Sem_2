#include "spaceObject.h"
#include "bonus.h"
#include <iostream>
using namespace std;

bonus :: bonus()
{
	cntAmmunition = 0;
	existingTime = 0;
}

void bonus::setCntAmmunition()
{
	cout << "Enter cntAmmunition" << endl;
	cin >> cntAmmunition;
	if (cntAmmunition < 0)
	{
		cout << "Incorrect value" << endl;
		exit(1);
	}
}
void bonus:: outputCntAmmunition()
{
	cout << "cntAmmunition : " << cntAmmunition << endl;
}
void bonus::setExistingTime()
{
	cout << "Enter existingTime" << endl;
	cin >> existingTime;
	if (existingTime < 0)
	{
		cout << "Incorrect value" << endl;
		exit(1);
	}
}
void bonus::outputExistingTime()
{
	cout << "existingTime: " << existingTime << endl;
}
void bonus::outData()
{
	cout << endl;
	cout << "Bonus: " << endl;
	outputCoordinates();
	outputSpeed();
	outputCntAmmunition();
	outputExistingTime();
	cout << endl;
}
