#include "spaceObject.h"
#include "spaceship.h"
#include <iostream>
using namespace std;

spaceship :: spaceship()
{
	maxSpeed = 0;
	ammunition = 0;
}

void spaceship::setMaxSpeed()
{
	cout << "Enter maxSpeed" << endl;
	cin >> maxSpeed;
	if (maxSpeed < 0)
	{
		cout << "Incorrect value" << endl;
		exit(1);
	}
}
void spaceship::outputMaxSpeed()
{
	cout << "maxSpeed: " << maxSpeed << endl;
}
void spaceship::setAmmunition()
{
	cout << "Enter Ammunition" << endl;
	cin >> ammunition;
	if (ammunition < 0)
	{
		cout << "Incorrect value" << endl;
		exit(1);
	}
}
void spaceship::outputAmmunition()
{
	cout << "Ammunition: " << ammunition << endl;
}
void spaceship::outData()
{
	cout << endl;
	cout << "Spaceship: " << endl;
	outputCoordinates();
	outputSpeed();
	outputMaxSpeed();
	outputAmmunition();
	cout << endl;
}