#pragma once
#include "spaceObject.h"
using namespace std;
class Asteroid : public  spaceObject
{
	int maxSize;

public:

	Asteroid();

		void setMaxSize();
		void outputMaxSize();
		void outData() override;
};