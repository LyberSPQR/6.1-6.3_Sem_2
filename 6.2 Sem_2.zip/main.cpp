﻿// 6.2 Sem_2.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include "spaceObject.h"
#include "Asteroid.h"
#include "spaceship.h"
#include "missle.h"
#include "bonus.h"
using namespace std;

class dynamicArrayObjects
{
	spaceObject** array;

	int g = 0;
	int Size = 10;
	int delCnt[10];
	int cnt = 0;
public:

	void readFile()
	{
		int flag = 0;
		ifstream inputFile("data_base.bin", ios::binary);

		if (!inputFile.is_open())
		{
			cout << "Не удалось открыть файл." << endl;
			return;
		}
		for (int i = 0; i < Size; i++)
		{
			for (int j = 0; j < Size; j++)
			{
				if (i == this->delCnt[j])
				{
					flag = 1;
					break;
				}
			}
			if (flag == 1)
			{
				flag = 0;
				continue;
			}
			else
			{
				inputFile.read(reinterpret_cast<char*>(&array[i]), sizeof(array[i]));
				this->array[i] = array[i];
			}
		}
		
	}
	void writeFile()
	{
		int flag = 0;
		ofstream outputFile("data_base.bin", ios::binary);

		if (!outputFile.is_open())
		{
			cout << "Не удалось открыть файл." << endl;
		}
		for (int i = 0; i < Size; i++)
		{
			for (int j = 0; j < Size; j++)
			{
				if (i == this->delCnt[j])
				{
					flag = 1;
					break;
				}
			}
			if (flag == 1)
			{
				flag = 0;
				continue;
			}
			else
			{
				outputFile.write(reinterpret_cast<char*>(&array[i]), sizeof(array[i]));
				
			}
		}

	}
	void delCntInic()
	{
		for (int i = 0; i < size(delCnt); i++)
		{
			delCnt[i] = -1;
		}
	}
	void getDelCnt()
	{
		cout << "DelCnt" << endl;
		for (int i = 0; i < size(delCnt); i++)
		{
			cout << delCnt[i] << " ";
				cout << endl;
		}
	}
	template<typename T>
 void addObject(T object);

 void deleteObject();
	void createArray();
	void deleteArray();
	
	void outArray();
	
};
void dynamicArrayObjects:: deleteObject()
{
	this->array[cnt - 1] = nullptr;
	this->delCnt[g] = cnt - 1;
	g++;
}
void dynamicArrayObjects::deleteArray()
{
	delete [] this->array;
}
void dynamicArrayObjects::outArray()
{
	bool flag;
	cout << "outArray" << endl;
	for (int i = 0; i < cnt; i++)
	{
		for (int j = 0; j < Size; j++)
		{
			if (i == this->delCnt[j])
			{
				flag = 1;
				break;
			}
		}
		if (flag == 1)
		{
			flag = 0;
				continue;
		}
		array[i]->outData();
	}
	
}
void dynamicArrayObjects ::  createArray()
{
	int sizeArray = 0;
	cout << "Enter size ArrayObjects" << endl;
		cin >> sizeArray;
	this->array = new spaceObject* [sizeArray];
}

template<typename T>
void dynamicArrayObjects:: addObject(T object)
{
	cout << "addObject" << endl;
	this->array[cnt] = dynamic_cast<spaceObject*>(new T(object));
	this->cnt++;
}

int main()
{
	Asteroid aster;
	spaceship ship;
	missle missl;
	bonus bonu;

//	Asteroid
	//aster.setCoordinates();
	//aster.setSpeed();
	//aster.setMaxSize();
	/*aster.outputAsteroidData();*/

//  Spaceship
	//ship.setCoordinates();
	//ship.setSpeed();
	//ship.setMaxSpeed();
	//ship.setAmmunition();
	//ship.outputSpaceshipData();



	//  Missle
	//missl.setCoordinates();
	//missl.setSpeed();
	//missl.setExplosivePower();
	//missl.setFuel_time();
	//missl.outputMissleData();

	//  Bonus
	//bonu.setCoordinates();
	//bonu.setSpeed();
	//bonu.setCntAmmunition();
	//bonu.setExistingTime();
	//bonu.outputBonusData();

	dynamicArrayObjects arr;
	arr.readFile();
	//arr.delCntInic();
	//arr.createArray();
	//arr.addObject(aster);
	//arr.deleteObject();
	//arr.addObject(ship);
	//arr.addObject(missl);
	//arr.deleteObject();
	//arr.addObject(bonu);
	arr.outArray();
	//arr.getDelCnt();
	//arr.writeFile();
	
	

	return 0;

}

