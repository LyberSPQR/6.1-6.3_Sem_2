#pragma once

#include <vector>
using namespace std;
class spaceObject
{
    vector<int> Coordinates;
	vector<int> Speed;
public:
	spaceObject();
		vector<int> getCoordinates();
		vector<int> getSpeed();
		void setCoordinates();
		void setSpeed();
		void outputSpeed();
		void outputCoordinates();
		virtual void outData();
};
