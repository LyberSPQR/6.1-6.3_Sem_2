#include "spaceObject.h"
#include "Asteroid.h"
#include <iostream>
using namespace std;
Asteroid :: Asteroid()
{
	maxSize = 10;
}

void Asteroid::setMaxSize()
{
	cout << "Enter maxSize" << endl;
	cin >> maxSize;
	if (maxSize < 0)
	{
		cout << "Incorrect value";
		exit(1);
	}
}
void Asteroid::outputMaxSize()
{
	cout << "maxSize: " << maxSize << endl;
}
void Asteroid::outData()
{
	cout << endl;
	cout << "Asteroid: " << endl;
	outputCoordinates();
	outputSpeed();
	outputMaxSize();
	cout << endl;
}