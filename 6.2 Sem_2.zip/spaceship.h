#pragma once
#include "spaceObject.h"
class spaceship : public  spaceObject
{
	int maxSpeed;
	int ammunition;

public:

	spaceship();

		void setMaxSpeed();
		void outputMaxSpeed();
		void setAmmunition();
		void outputAmmunition();
		void outData() override;
};