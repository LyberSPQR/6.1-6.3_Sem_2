#include "spaceObject.h"
#include <iostream>
#include <vector>
using namespace std;
spaceObject :: spaceObject()
{
	cout << "Base inicialisation" << endl;
	for (int i = 0; i < 3; i++)
	{
        Coordinates.push_back(2);
		Speed.push_back(2);
	}
}
vector<int> spaceObject :: getCoordinates()
{
    return this->Coordinates;
}
vector<int> spaceObject :: getSpeed()
{
	return this->Speed;
}
void  spaceObject :: setCoordinates()
{
	cout << "Enter values of coordinates (X,Y,Z)" << endl;
	for (int i = 0; i < 3; i++)
	{
        cin >> Coordinates[i];
        if (Coordinates[i] < 0)
		{
			cout << "Incorrect value" << endl;
			exit(1);
		}
	}
}
void  spaceObject :: setSpeed()
{
	cout << "Enter values of speed ( V(x),V(y),V(z) )" << endl;
	for (int i = 0; i < 3; i++)
	{
		cin >> Speed[i];
		if (Speed[i] < 0)
		{
			cout << "Incorrect value";
			exit(1);
		}
	}
}
void  spaceObject :: outputSpeed()
{
	cout << "Speed V(x),V(y),V(z)" << endl;
	for (int i = 0; i < 3; i++)
	{
		cout << Speed[i] << "  ";
	}
	cout << endl;
}
void  spaceObject :: outputCoordinates()
{
	cout << "Coordinates (X,Y,Z)" << endl;
	for (int i = 0; i < 3; i++)
	{
        cout << Coordinates[i] << "  ";
	}
	cout << endl;
}
 void  spaceObject::outData()
{
	cout << "why you see that?" << endl;
}
