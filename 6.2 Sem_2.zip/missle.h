#pragma once
#include "spaceObject.h"
class missle : public  spaceObject
{
	int explosivePower;
	int fuel_time;
public:

	missle();

		void setExplosivePower();
		void outputExplosivePower();
		void setFuel_time();
		void outputFuel_time();
		void outData() override;
};